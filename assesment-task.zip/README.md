# Getting Started with Student App

Please create a DB with named as 'studentlist'.

Update the DB connection information on server\inde.js file.

Then, Run below comments,

### `npm install`
### `npm start`
### `cd server> npm install`
### `npm start`